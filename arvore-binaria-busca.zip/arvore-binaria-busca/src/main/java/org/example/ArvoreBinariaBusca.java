package org.example;

public class ArvoreBinariaBusca {
    private Node raiz;

    public ArvoreBinariaBusca() {
        this.raiz = null;
    }

    public Node getRaiz() {
        return raiz;
    }

    public void insere(int info){
        if(getRaiz() == null){
            this.raiz = new Node(info);
        }else{
            Node noDaVez = getRaiz();
            while (noDaVez != null && noDaVez.getInfo() != info){
                Node novo = new Node(info);
                if(info <= noDaVez.getInfo()){
                    if(noDaVez.getEsq() == null){
                        noDaVez.setEsq(novo);
                    }
                    noDaVez = noDaVez.getEsq();
                }else{
                    if(noDaVez.getDir() == null){
                        noDaVez.setDir(novo);
                    }
                    noDaVez = noDaVez.getDir();
                }
            }
        }
    }

    public void preOrdem(Node daVez){
        if(daVez != null) {
            System.out.print(daVez.getInfo() + "\t");
            preOrdem(daVez.getEsq());
            preOrdem(daVez.getDir());
        }
    }

    public void emOrdem(Node daVez){
        if(daVez != null) {
            emOrdem(daVez.getEsq());
            System.out.print(daVez.getInfo() + "\t");
            emOrdem(daVez.getDir());
        }
    }

    public void posOrdem(Node daVez){
        if(daVez != null) {
            posOrdem(daVez.getEsq());
            posOrdem(daVez.getDir());
            System.out.print(daVez.getInfo() + "\t");
        }
    }

    public Node buscaNo(int valor, Node daVez){
        if(daVez == null || daVez.getInfo() == valor){
            return daVez;
        }
        if(valor < daVez.getInfo()){
            return buscaNo(valor, daVez.getEsq());
        }else{
            return buscaNo(valor, daVez.getDir());
        }
    }

}
